﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class Aviao : INaoVivo, IVoador
    {
        public void decolar()
        {
        }

        public void desligar()
        {
        }

        public void emitir_alerta()
        {
        }

        public void ligar()
        {
        }

        public void pousar()
        {
        }

        public void voar()
        {
        }
    }
}