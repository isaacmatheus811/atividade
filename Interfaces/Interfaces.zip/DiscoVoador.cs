﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class DiscoVoador : INaoVivo, IPairador
    {
        public void decolar()
        {
        }

        public void desligar()
        {
        }

        public void emitir_alerta()
        {
        }

        public void ligar()
        {
        }

        public void Pairar()
        {
        }

        public void pousar()
        {
        }

        public void voar()
        {
        }
    }
}