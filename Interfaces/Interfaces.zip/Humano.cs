﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class Humano : ISerVivo
    {
        public void comer()
        {
        }

        public void defecar()
        {
        }

        public void dormir()
        {
        }

        public void respirar()
        {
        }

        public void urinar()
        {
        }
    }
}
