﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal interface ISerVivo
    {
        public void comer();
        public void urinar();
        public void defecar();
        public void dormir();
        public void respirar();
    }
}
