﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces

{
    internal class Maquina : INaoVivo
    {
        public void desligar()
        {
        }

        public void emitir_alerta()
        {
        }

        public void ligar()
        {
        }
    }
}
