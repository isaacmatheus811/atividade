﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class Passaros : ISerVivo, IVoador
    {
        public void comer()
        {
        }

        public void decolar()
        {
        }

        public void defecar()
        {
        }

        public void dormir()
        {
        }

        public void pousar()
        {
        }

        public void respirar()
        {
        }

        public void urinar()
        {
        }

        public void voar()
        {
        }
    }
}
