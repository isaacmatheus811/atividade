﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class SuperHomem : ISerVivo, IPairador
    {
        public void comer()
        {
        }
        public void decolar()
        {
        }
        public void defecar()
        {
        }
        public void dormir()
        {
        }
        public void Pairar()
        {
        }
        public void pousar()
        {
        }
        public void respirar()
        {
        }
        public void urinar()
        {
        }
        public void voar()
        {
        }
    }
}